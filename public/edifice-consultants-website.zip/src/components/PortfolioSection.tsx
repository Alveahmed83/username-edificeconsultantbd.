import React, { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import {
  ArchitecturalProject,
  PORTFOLIO_PROJECTS,
  ProjectCategory,
} from '../data/companyData';
import { PortfolioBlueprint } from './PortfolioBlueprint';
import { ProjectDossierModal } from './ProjectDossierModal';

const CATEGORIES: ProjectCategory[] = [
  'All',
  'Commercial',
  'Residential',
  'Institutional',
  'Industrial',
];

interface PortfolioSectionProps {
  onInquireProject: (projectTitle: string) => void;
}

export const PortfolioSection: React.FC<PortfolioSectionProps> = ({
  onInquireProject,
}) => {
  const [activeCategory, setActiveCategory] = useState<ProjectCategory>('All');
  const [selectedProject, setSelectedProject] =
    useState<ArchitecturalProject | null>(null);

  const filteredProjects =
    activeCategory === 'All'
      ? PORTFOLIO_PROJECTS
      : PORTFOLIO_PROJECTS.filter((p) => p.category === activeCategory);

  return (
    <section
      id="portfolio"
      className="py-20 lg:py-28 border-t border-zinc-200 bg-[#FAFAFA]"
    >
      <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
        {/* Section Header + Interactive Filter Controls */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <p className="text-xs font-mono tracking-wide text-[#D94A27] font-medium mb-3">
              Selected Typologies &amp; Commissions
            </p>
            <h2 className="font-display text-3xl lg:text-4xl font-bold tracking-tight text-zinc-950 text-balance">
              Architectural clarity across scale and climate
            </h2>
            <p className="mt-3 text-base text-zinc-600 leading-relaxed">
              Representative commercial towers, tropical residences, academic
              campuses, and industrial facilities engineered for structural
              longevity and environmental performance.
            </p>
          </div>

          {/* Functional Segmented Filter Buttons */}
          <div
            role="tablist"
            aria-label="Filter projects by typology"
            className="inline-flex flex-wrap items-center gap-1 p-1 bg-zinc-100 border border-zinc-200 rounded-lg self-start lg:self-auto"
          >
            {CATEGORIES.map((category) => {
              const active = activeCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setActiveCategory(category)}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D94A27] ${
                    active
                      ? 'bg-white text-zinc-950 shadow-sm'
                      : 'text-zinc-600 hover:text-zinc-950'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        {/* Architectural Drawing Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {filteredProjects.map((project) => (
            <article
              key={project.id}
              className="group bg-white border border-zinc-200 rounded-xl overflow-hidden flex flex-col justify-between transition-transform duration-200 hover:-translate-y-0.5"
            >
              <div>
                <PortfolioBlueprint
                  variant={project.blueprintVariant}
                  code={project.code}
                />

                <div className="p-6">
                  {/* Unboxed Metadata (Zero-Pill Rule) */}
                  <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500 mb-2.5">
                    <span className="font-medium text-zinc-700">
                      {project.category}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{project.location}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{project.scale}</span>
                  </div>

                  <h3 className="font-display text-xl font-bold tracking-tight text-zinc-950 group-hover:text-[#D94A27] transition-colors duration-150">
                    {project.title}
                  </h3>

                  <p className="mt-2.5 text-sm text-zinc-600 leading-relaxed line-clamp-3">
                    {project.summary}
                  </p>
                </div>
              </div>

              <div className="px-6 py-4 border-t border-zinc-100 flex items-center justify-between gap-4">
                <span className="font-mono text-xs text-zinc-500">
                  {project.stories}
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedProject(project)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-950 hover:text-[#D94A27] transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D94A27] rounded-sm"
                >
                  Inspect Dossier
                  <ArrowUpRight size={14} />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>

      {selectedProject && (
        <ProjectDossierModal
          project={selectedProject}
          onClose={() => setSelectedProject(null)}
          onRequestConsultation={(title) => {
            setSelectedProject(null);
            onInquireProject(title);
          }}
        />
      )}
    </section>
  );
};
