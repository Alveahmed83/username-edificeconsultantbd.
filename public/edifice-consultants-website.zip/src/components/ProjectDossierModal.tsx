import React, { useEffect } from 'react';
import { X, ArrowRight } from 'lucide-react';
import { ArchitecturalProject } from '../data/companyData';
import { PortfolioBlueprint } from './PortfolioBlueprint';

interface ProjectDossierModalProps {
  project: ArchitecturalProject;
  onClose: () => void;
  onRequestConsultation: (projectTitle: string) => void;
}

export const ProjectDossierModal: React.FC<ProjectDossierModalProps> = ({
  project,
  onClose,
  onRequestConsultation,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="dossier-title"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-white border border-zinc-200 rounded-xl shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="sticky top-0 z-20 flex items-center justify-between gap-4 px-6 py-4 bg-white/95 backdrop-blur-xs border-b border-zinc-200">
          <div className="flex items-center gap-2 text-xs text-zinc-500 font-mono">
            <span className="text-[#D94A27] font-semibold">{project.code}</span>
            <span aria-hidden="true">·</span>
            <span>{project.category}</span>
            <span aria-hidden="true">·</span>
            <span>{project.year}</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close project dossier"
            className="w-9 h-9 inline-flex items-center justify-center rounded-md text-zinc-600 hover:text-zinc-950 hover:bg-zinc-100 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D94A27]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Drawing & Content */}
        <PortfolioBlueprint variant={project.blueprintVariant} code={project.code} />

        <div className="p-6 sm:p-8 space-y-6">
          <div>
            <p className="text-xs text-zinc-500 mb-1.5">
              {project.location} <span aria-hidden="true">·</span> {project.stories}
            </p>
            <h3
              id="dossier-title"
              className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-zinc-950"
            >
              {project.title}
            </h3>
          </div>

          <div className="space-y-3 text-sm sm:text-base text-zinc-700 leading-relaxed">
            <p>{project.summary}</p>
            <p className="text-zinc-600">{project.designThesis}</p>
          </div>

          {/* Technical Specification Grid */}
          <div className="border-t border-b border-zinc-200 py-5">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-5">
              {project.performanceMetrics.map((metric) => (
                <div key={metric.label}>
                  <p className="text-xs text-zinc-500 mb-1">{metric.label}</p>
                  <p className="font-mono text-sm font-semibold text-zinc-950">
                    {metric.value}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-1">
            <div>
              <p className="text-xs text-zinc-500">Structural Framework</p>
              <p className="text-sm font-medium text-zinc-900">
                {project.structuralSystem}
              </p>
            </div>

            <button
              type="button"
              onClick={() => onRequestConsultation(project.title)}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#D94A27] hover:bg-[#B83819] rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Discuss Similar Commission
              <ArrowRight size={15} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
