import React from 'react';
import { ArchitecturalProject } from '../data/companyData';

interface PortfolioBlueprintProps {
  variant: ArchitecturalProject['blueprintVariant'];
  code: string;
}

export const PortfolioBlueprint: React.FC<PortfolioBlueprintProps> = ({
  variant,
  code,
}) => {
  return (
    <div className="relative w-full aspect-[4/3] bg-[#F4F4F5] border-b border-zinc-200 overflow-hidden flex items-center justify-center p-5">
      {/* Subtle coordinate lines */}
      <div
        className="absolute inset-0 pointer-events-none opacity-60"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(20,20,22,0.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(20,20,22,0.04) 1px, transparent 1px)',
          backgroundSize: '24px 24px',
        }}
      />

      {/* Drawing Sheet Corner Code */}
      <span className="absolute top-3.5 left-4 font-mono text-[11px] text-zinc-500 tracking-tight">
        DWG {code}
      </span>
      <span className="absolute top-3.5 right-4 font-mono text-[11px] text-[#D94A27] font-medium">
        SCALE 1:200
      </span>

      <svg
        viewBox="0 0 320 210"
        className="relative z-10 w-full h-full max-w-[290px]"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        {/* Ground datum */}
        <line x1="20" y1="184" x2="300" y2="184" stroke="#18181B" strokeWidth="1.5" />

        {variant === 'tower' && (
          <g>
            {/* Podium */}
            <rect x="64" y="144" width="192" height="40" fill="#FFFFFF" stroke="#18181B" strokeWidth="1.4" />
            {/* Main Tower */}
            <rect x="96" y="28" width="128" height="116" fill="#FFFFFF" stroke="#18181B" strokeWidth="1.4" />
            {/* Side Core */}
            <rect x="224" y="54" width="22" height="130" fill="#E4E4E7" stroke="#18181B" strokeWidth="1.2" />
            {/* Terracotta Louver Fins */}
            {[40, 56, 72, 88, 104, 120, 136].map((y) => (
              <line key={y} x1="96" y1={y} x2="224" y2={y} stroke="#D94A27" strokeWidth="1.2" />
            ))}
            {[118, 140, 162, 184, 206].map((x) => (
              <line key={x} x1={x} y1="28" x2={x} y2="184" stroke="#71717A" strokeWidth="0.7" strokeDasharray="2 2" />
            ))}
            {/* Dimension marker */}
            <line x1="42" y1="28" x2="42" y2="184" stroke="#D94A27" strokeWidth="1" />
            <line x1="38" y1="28" x2="46" y2="28" stroke="#D94A27" strokeWidth="1" />
            <line x1="38" y1="184" x2="46" y2="184" stroke="#D94A27" strokeWidth="1" />
          </g>
        )}

        {variant === 'courtyard' && (
          <g>
            {/* Left & Right Masses framing open courtyard */}
            <rect x="46" y="76" width="84" height="108" fill="#FFFFFF" stroke="#18181B" strokeWidth="1.4" />
            <rect x="190" y="64" width="84" height="120" fill="#FFFFFF" stroke="#18181B" strokeWidth="1.4" />
            {/* Cantilevered upper bridge */}
            <rect x="78" y="48" width="164" height="28" fill="#FFFFFF" stroke="#18181B" strokeWidth="1.5" />
            {/* Terracotta brick screen */}
            <rect x="130" y="76" width="60" height="72" fill="#D94A27" fillOpacity="0.12" stroke="#D94A27" strokeWidth="1.2" />
            {[88, 100, 112, 124, 136].map((y) => (
              <line key={y} x1="130" y1={y} x2="190" y2={y} stroke="#D94A27" strokeWidth="0.9" />
            ))}
            {/* Trees / Courtyard Section */}
            <circle cx="160" cy="166" r="10" stroke="#52525B" strokeWidth="1" fill="#E4E4E7" />
            <line x1="160" y1="166" x2="160" y2="184" stroke="#18181B" strokeWidth="1.2" />
          </g>
        )}

        {variant === 'campus' && (
          <g>
            {/* Main Long-Span Academic Block */}
            <rect x="40" y="88" width="240" height="96" fill="#FFFFFF" stroke="#18181B" strokeWidth="1.4" />
            {/* Sawtooth Clerestory Roof */}
            <polygon points="40,88 90,56 90,88" fill="#E4E4E7" stroke="#18181B" strokeWidth="1.3" />
            <polygon points="90,88 140,56 140,88" fill="#E4E4E7" stroke="#18181B" strokeWidth="1.3" />
            <polygon points="140,88 190,56 190,88" fill="#E4E4E7" stroke="#18181B" strokeWidth="1.3" />
            <polygon points="190,88 240,56 240,88" fill="#E4E4E7" stroke="#18181B" strokeWidth="1.3" />
            {/* North Glazing accents */}
            <line x1="90" y1="56" x2="90" y2="88" stroke="#D94A27" strokeWidth="1.8" />
            <line x1="140" y1="56" x2="140" y2="88" stroke="#D94A27" strokeWidth="1.8" />
            <line x1="190" y1="56" x2="190" y2="88" stroke="#D94A27" strokeWidth="1.8" />
            {/* Waffle slab floor bands */}
            <line x1="40" y1="120" x2="280" y2="120" stroke="#18181B" strokeWidth="1" />
            <line x1="40" y1="152" x2="280" y2="152" stroke="#18181B" strokeWidth="1" />
            {/* Structural Columns */}
            {[88, 136, 184, 232].map((x) => (
              <line key={x} x1={x} y1="88" x2={x} y2="184" stroke="#71717A" strokeWidth="1" />
            ))}
          </g>
        )}

        {variant === 'mixed' && (
          <g>
            {/* Stepped Commercial Podium */}
            <rect x="44" y="132" width="232" height="52" fill="#FFFFFF" stroke="#18181B" strokeWidth="1.4" />
            <rect x="74" y="88" width="172" height="44" fill="#FFFFFF" stroke="#18181B" strokeWidth="1.4" />
            <rect x="108" y="34" width="104" height="54" fill="#FFFFFF" stroke="#18181B" strokeWidth="1.4" />
            {/* Atrium void */}
            <rect x="136" y="132" width="48" height="52" fill="#D94A27" fillOpacity="0.14" stroke="#D94A27" strokeWidth="1.2" />
            {/* Sky garden terrace markers */}
            <line x1="74" y1="84" x2="108" y2="84" stroke="#D94A27" strokeWidth="2.2" />
            <line x1="212" y1="84" x2="246" y2="84" stroke="#D94A27" strokeWidth="2.2" />
            {/* Vertical mullion lines */}
            {[128, 148, 172, 192].map((x) => (
              <line key={x} x1={x} y1="34" x2={x} y2="132" stroke="#A1A1AA" strokeWidth="0.8" />
            ))}
          </g>
        )}

        {variant === 'industrial' && (
          <g>
            {/* Portal Frame */}
            <polygon
              points="36,184 36,92 160,64 284,92 284,184"
              fill="#FFFFFF"
              stroke="#18181B"
              strokeWidth="1.5"
            />
            {/* Ridge Thermal Exhaust Monitor */}
            <rect x="130" y="50" width="60" height="16" fill="#D94A27" fillOpacity="0.18" stroke="#D94A27" strokeWidth="1.3" />
            {/* Steel Truss Bracing */}
            <line x1="36" y1="92" x2="284" y2="92" stroke="#71717A" strokeWidth="1" />
            <line x1="36" y1="92" x2="98" y2="78" stroke="#71717A" strokeWidth="0.9" />
            <line x1="98" y1="92" x2="160" y2="64" stroke="#71717A" strokeWidth="0.9" />
            <line x1="160" y1="64" x2="222" y2="92" stroke="#71717A" strokeWidth="0.9" />
            {/* Loading Bays */}
            {[56, 112, 168, 224].map((x) => (
              <rect
                key={x}
                x={x}
                y="132"
                width="40"
                height="52"
                fill="#F4F4F5"
                stroke="#18181B"
                strokeWidth="1.1"
              />
            ))}
          </g>
        )}

        {variant === 'pavilion' && (
          <g>
            {/* Horizontal Floating Roof Slab */}
            <rect x="34" y="78" width="252" height="14" fill="#18181B" />
            {/* Main Pavilion Box */}
            <rect x="58" y="92" width="204" height="78" fill="#FFFFFF" stroke="#18181B" strokeWidth="1.4" />
            {/* Reflecting Water Pool Base */}
            <rect x="44" y="170" width="232" height="14" fill="#D94A27" fillOpacity="0.15" stroke="#D94A27" strokeWidth="1" />
            {/* Operable Vertical Louver Bay */}
            {[82, 92, 102, 112, 122, 132, 142].map((x) => (
              <line key={x} x1={x} y1="92" x2={x} y2="170" stroke="#D94A27" strokeWidth="1.2" />
            ))}
            {/* Gallery Glass Partition */}
            <rect x="166" y="102" width="76" height="68" fill="#F4F4F5" stroke="#71717A" strokeWidth="1" />
          </g>
        )}
      </svg>
    </div>
  );
};
