import React, { useState } from 'react';
import { Layers, Compass } from 'lucide-react';

type ViewMode = 'skyline' | 'blueprint';

export const ArchitecturalHeroCanvas: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>('skyline');
  const [selectedTower, setSelectedTower] = useState<number>(2);

  const towers = [
    {
      id: 0,
      name: 'West Podium Wing',
      floors: '12F',
      heightM: '48.0m',
      x: 34,
      y: 235,
      w: 58,
      h: 225,
      cols: 4,
      rows: 13,
    },
    {
      id: 1,
      name: 'North Atrium Block',
      floors: '16F',
      heightM: '64.0m',
      x: 102,
      y: 165,
      w: 72,
      h: 295,
      cols: 5,
      rows: 17,
    },
    {
      id: 2,
      name: 'Planners Axis Core',
      floors: '22F',
      heightM: '88.4m',
      x: 184,
      y: 88,
      w: 94,
      h: 372,
      cols: 6,
      rows: 22,
    },
    {
      id: 3,
      name: 'South Louver Tower',
      floors: '18F',
      heightM: '72.0m',
      x: 288,
      y: 138,
      w: 78,
      h: 322,
      cols: 5,
      rows: 19,
    },
    {
      id: 4,
      name: 'East Studio Annex',
      floors: '14F',
      heightM: '56.0m',
      x: 376,
      y: 205,
      w: 68,
      h: 255,
      cols: 4,
      rows: 15,
    },
  ];

  const activeTower = towers[selectedTower];
  const isBlueprint = viewMode === 'blueprint';

  return (
    <div
      className={`relative h-full min-h-[440px] lg:min-h-[540px] rounded-xl border overflow-hidden flex flex-col justify-between transition-colors duration-200 ${
        isBlueprint
          ? 'bg-[#101622] border-slate-800 text-slate-100'
          : 'bg-[#141416] border-zinc-800 text-zinc-100'
      }`}
    >
      {/* Subtle architectural drafting grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-35"
        style={{
          backgroundImage: isBlueprint
            ? 'linear-gradient(to right, rgba(148,163,184,0.14) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,163,184,0.14) 1px, transparent 1px)'
            : 'linear-gradient(to right, rgba(255,255,255,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.06) 1px, transparent 1px)',
          backgroundSize: '32px 32px',
        }}
      />

      {/* Top Interactive Mode Switch inside Visual Frame */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 px-5 pt-5">
        <div className="text-xs font-mono text-zinc-400">
          <span>DHAKA URBAN SKYLINE STUDY</span>
          <span className="mx-2 text-zinc-600">·</span>
          <span className="text-zinc-200">{activeTower.name}</span>
        </div>

        <div
          role="tablist"
          aria-label="Architectural drawing mode"
          className="inline-flex items-center gap-1 p-1 rounded-lg bg-white/5 border border-white/10"
        >
          <button
            type="button"
            role="tab"
            aria-selected={viewMode === 'skyline'}
            onClick={() => setViewMode('skyline')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
              viewMode === 'skyline'
                ? 'bg-[#D94A27] text-white'
                : 'text-zinc-300 hover:text-white'
            }`}
          >
            <Layers size={13} />
            Perspective
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={viewMode === 'blueprint'}
            onClick={() => setViewMode('blueprint')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
              viewMode === 'blueprint'
                ? 'bg-[#D94A27] text-white'
                : 'text-zinc-300 hover:text-white'
            }`}
          >
            <Compass size={13} />
            CAD Elevation
          </button>
        </div>
      </div>

      {/* Central Interactive SVG Skyline inspired by the visiting card back */}
      <div className="relative z-10 flex-1 flex items-end justify-center px-4 pt-4">
        <svg
          viewBox="0 0 480 470"
          className="w-full h-full max-h-[430px] select-none"
          role="img"
          aria-label="Interactive architectural tower elevation inspired by Edifice Consultants visiting card"
        >
          {/* Elevation Datum Lines */}
          {[100, 180, 260, 340, 420].map((yVal, idx) => (
            <g key={yVal}>
              <line
                x1="14"
                y1={yVal}
                x2="466"
                y2={yVal}
                stroke={isBlueprint ? '#38BDF8' : '#71717A'}
                strokeOpacity={isBlueprint ? 0.22 : 0.16}
                strokeDasharray="3 5"
                strokeWidth="1"
              />
              <text
                x="14"
                y={yVal - 5}
                fill={isBlueprint ? '#7DD3FC' : '#71717A'}
                fontSize="8.5"
                fontFamily="JetBrains Mono, monospace"
                opacity="0.7"
              >
                +{(5 - idx) * 18}.0m
              </text>
            </g>
          ))}

          {/* Ground Plane */}
          <line
            x1="12"
            y1="460"
            x2="468"
            y2="460"
            stroke={isBlueprint ? '#38BDF8' : '#D94A27'}
            strokeWidth="1.5"
          />

          {/* Interactive Towers */}
          {towers.map((tower) => {
            const isSelected = tower.id === selectedTower;
            const winW = (tower.w - 14) / tower.cols;
            const winH = (tower.h - 22) / tower.rows;

            return (
              <g
                key={tower.id}
                onClick={() => setSelectedTower(tower.id)}
                onMouseEnter={() => setSelectedTower(tower.id)}
                className="cursor-pointer transition-opacity duration-150"
              >
                {/* Perspective side volume */}
                <polygon
                  points={`${tower.x + tower.w},${tower.y} ${tower.x + tower.w + 14},${tower.y + 10} ${tower.x + tower.w + 14},460 ${tower.x + tower.w},460`}
                  fill={
                    isBlueprint
                      ? isSelected
                        ? 'rgba(217, 74, 39, 0.22)'
                        : 'rgba(56, 189, 248, 0.08)'
                      : isSelected
                      ? '#27272A'
                      : '#1C1C20'
                  }
                  stroke={
                    isSelected
                      ? '#D94A27'
                      : isBlueprint
                      ? 'rgba(125, 211, 252, 0.45)'
                      : 'rgba(161, 161, 170, 0.3)'
                  }
                  strokeWidth="1"
                />

                {/* Main Facade Plane */}
                <rect
                  x={tower.x}
                  y={tower.y}
                  width={tower.w}
                  height={tower.h}
                  fill={
                    isBlueprint
                      ? isSelected
                        ? 'rgba(15, 23, 42, 0.92)'
                        : 'rgba(15, 23, 42, 0.72)'
                      : isSelected
                      ? '#1F1F23'
                      : '#18181B'
                  }
                  stroke={
                    isSelected
                      ? '#D94A27'
                      : isBlueprint
                      ? 'rgba(125, 211, 252, 0.55)'
                      : 'rgba(161, 161, 170, 0.4)'
                  }
                  strokeWidth={isSelected ? '1.6' : '1'}
                />

                {/* Roof Louver Crown */}
                <rect
                  x={tower.x + 6}
                  y={tower.y - 10}
                  width={tower.w - 12}
                  height={10}
                  fill={isSelected ? '#D94A27' : isBlueprint ? '#1E293B' : '#27272A'}
                  stroke={
                    isSelected
                      ? '#D94A27'
                      : isBlueprint
                      ? 'rgba(125, 211, 252, 0.5)'
                      : 'rgba(161, 161, 170, 0.4)'
                  }
                  strokeWidth="1"
                />

                {/* Halftone Architectural Window Matrix (directly honoring card back graphic) */}
                {Array.from({ length: tower.rows }).map((_, rIdx) =>
                  Array.from({ length: tower.cols }).map((__, cIdx) => {
                    const wx = tower.x + 8 + cIdx * winW;
                    const wy = tower.y + 12 + rIdx * winH;
                    const isTerracottaBand =
                      isSelected && (rIdx === 2 || rIdx === 3 || (tower.id === 2 && rIdx === 3));

                    return (
                      <rect
                        key={`${rIdx}-${cIdx}`}
                        x={wx}
                        y={wy}
                        width={Math.max(winW - 3.5, 3)}
                        height={Math.max(winH - 4.5, 2.5)}
                        fill={
                          isTerracottaBand
                            ? '#D94A27'
                            : isBlueprint
                            ? isSelected
                              ? '#7DD3FC'
                              : '#38BDF8'
                            : isSelected
                            ? '#E4E4E7'
                            : '#71717A'
                        }
                        fillOpacity={
                          isTerracottaBand
                            ? 0.95
                            : isSelected
                            ? 0.72
                            : (rIdx + cIdx) % 3 === 0
                            ? 0.45
                            : 0.24
                        }
                      />
                    );
                  })
                )}

                {/* Floor-19 Studio Highlight Marker on Core Tower */}
                {tower.id === 2 && (
                  <g>
                    <line
                      x1={tower.x - 16}
                      y1={tower.y + 52}
                      x2={tower.x + tower.w + 18}
                      y2={tower.y + 52}
                      stroke="#D94A27"
                      strokeWidth="1.2"
                      strokeDasharray="2 2"
                    />
                    <rect
                      x={tower.x + tower.w + 20}
                      y={tower.y + 42}
                      width="76"
                      height="19"
                      rx="3"
                      fill="#D94A27"
                    />
                    <text
                      x={tower.x + tower.w + 26}
                      y={tower.y + 54.5}
                      fill="#FFFFFF"
                      fontSize="8.5"
                      fontFamily="JetBrains Mono, monospace"
                      fontWeight="600"
                    >
                      FLOOR-19 HQ
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>
      </div>

      {/* Bottom Dimension Readout Bar */}
      <div className="relative z-10 border-t border-white/10 bg-black/30 px-5 py-3.5 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-4 font-mono text-zinc-300">
          <span>
            LEVELS: <strong className="text-white">{activeTower.floors}</strong>
          </span>
          <span className="text-zinc-600">/</span>
          <span>
            DATUM: <strong className="text-white">{activeTower.heightM}</strong>
          </span>
        </div>
        <span className="text-zinc-400">
          Select any tower volume to inspect elevation datum
        </span>
      </div>
    </div>
  );
};
