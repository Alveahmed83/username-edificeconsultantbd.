export type ProjectCategory =
  | 'All'
  | 'Commercial'
  | 'Residential'
  | 'Institutional'
  | 'Industrial';

export interface ArchitecturalProject {
  id: string;
  code: string;
  title: string;
  category: Exclude<ProjectCategory, 'All'>;
  location: string;
  year: string;
  scale: string;
  stories: string;
  structuralSystem: string;
  summary: string;
  designThesis: string;
  performanceMetrics: {
    label: string;
    value: string;
  }[];
  blueprintVariant: 'tower' | 'courtyard' | 'campus' | 'pavilion' | 'industrial' | 'mixed';
}

export interface CapabilityItem {
  index: string;
  title: string;
  scope: string;
  deliverables: string[];
  highlightMetric: string;
  spanWide?: boolean;
}

export interface ApplianceLine {
  id: string;
  code: string;
  name: string;
  category: string;
  summary: string;
  engineeringFocus: string;
  specs: {
    label: string;
    value: string;
  }[];
  architecturalIntegration: string;
}

export const COMPANY_INFO = {
  name: 'Edifice Consultants',
  applianceDivision: 'Edifice Home Appliances',
  tagline: 'The Nexus of Art & Technology',
  principal: {
    name: 'Faruk Ahmed',
    credentials: 'Architect, MIAB A-140',
    academic: 'Former Faculty, Department of Architecture, BUET',
    rolePrimary: 'Principal Architect, Edifice Consultants',
    roleSecondary: 'Proprietor & Designer, Edifice Home Appliances',
    phoneDisplay: '+880 1682-947555',
    phoneRaw: '+8801682947555',
    phoneLocal: '01682947555',
    personalEmail: 'faruk1207@gmail.com',
  },
  office: {
    email: 'edifice.consultants.bd@gmail.com',
    floor: 'Floor-19',
    building: 'Planners Tower',
    area: 'Bangla Motor',
    city: 'Dhaka-1000',
    country: 'Bangladesh',
    fullAddress: 'Floor-19, Planners Tower, Bangla Motor, Dhaka-1000, Bangladesh',
    coordinates: '23.7461° N, 90.3942° E',
    hours: 'Sunday – Thursday · 10:00 AM – 6:30 PM BST',
  },
} as const;

export const CAPABILITIES: CapabilityItem[] = [
  {
    index: '01',
    title: 'Architectural Design & Masterplanning',
    scope:
      'Climate-responsive spatial planning, urban feasibility studies, and RAJUK / BNBC compliant architectural documentation for high-density sites across Bangladesh.',
    deliverables: [
      'Site Feasibility & FAR Optimization',
      'Schematic & Concept Architecture',
      'Full Working Drawings & Detailing',
    ],
    highlightMetric: 'BNBC 2020 & RAJUK Compliant Delivery',
    spanWide: true,
  },
  {
    index: '02',
    title: 'Structural & MEP Engineering',
    scope:
      'Integrated seismic-resistant structural frameworks, wind-load analysis for tall towers, and coordinated electrical, HVAC, and plumbing systems.',
    deliverables: [
      'Seismic RCC & Composite Steel Frames',
      'MEP Coordination & Load Scheduling',
      'Fire Safety & Life-Safety Engineering',
    ],
    highlightMetric: 'Seismic Zone 2 Engineered Margins',
  },
  {
    index: '03',
    title: 'Interior Architecture & Spatial Systems',
    scope:
      'Bespoke corporate headquarters, executive suites, and residential interiors engineered around daylight harvesting, acoustics, and durable local materials.',
    deliverables: [
      'Spatial Programming & Acoustic Zoning',
      'Custom Millwork & Lighting Integration',
      'Turnkey Site Supervision',
    ],
    highlightMetric: 'Precision Millimeter Execution',
  },
  {
    index: '04',
    title: 'Industrial & Appliance Design',
    scope:
      'Led directly through Edifice Home Appliances, translating architectural proportion and thermal engineering into reliable everyday domestic hardware.',
    deliverables: [
      'Ergonomic Industrial Form Factor',
      'Thermal & Airflow Optimization',
      'Modular Architectural Built-In Fitment',
    ],
    highlightMetric: 'Dual Architecture & Hardware Studio',
    spanWide: true,
  },
];

export const STUDIO_METRICS = [
  {
    value: 'MIAB A-140',
    label: 'Senior Registration',
    detail: 'Institute of Architects Bangladesh',
  },
  {
    value: 'BUET',
    label: 'Academic Pedigree',
    detail: 'Former Architecture Faculty',
  },
  {
    value: 'Floor-19',
    label: 'Bangla Motor Studio',
    detail: 'Planners Tower, Dhaka-1000',
  },
  {
    value: '2 Divisions',
    label: 'Unified Practice',
    detail: 'Architecture & Home Appliances',
  },
];

export const PORTFOLIO_PROJECTS: ArchitecturalProject[] = [
  {
    id: 'bangla-motor-commercial',
    code: 'EC-COM-01',
    title: 'Planners Axis Corporate Tower',
    category: 'Commercial',
    location: 'Bangla Motor, Dhaka',
    year: '2025',
    scale: '164,000 sq. ft.',
    stories: '20 Stories + 3 Basements',
    structuralSystem: 'Post-Tensioned Flat Plate RCC Core',
    summary:
      'A high-efficiency vertical commercial headquarters anchored by a double-height terracotta louver facade engineered to cut solar heat gain along the western elevation.',
    designThesis:
      'Dense Dhaka commercial corridors face intense western solar radiation and acoustic street loads. By layering deep recessed structural fins and a ventilated double-skin core, the tower reduces peak cooling demand while preserving panoramic urban daylight.',
    performanceMetrics: [
      { label: 'Gross Built Area', value: '164,000 sq. ft.' },
      { label: 'Solar Heat Reduction', value: '34% West Facade' },
      { label: 'Structural Grid', value: '8.4m × 8.4m Span' },
      { label: 'Parking Capacity', value: '112 Vehicles' },
    ],
    blueprintVariant: 'tower',
  },
  {
    id: 'gulshan-pavilion-residence',
    code: 'EC-RES-04',
    title: 'Courtyard Lattice Residence',
    category: 'Residential',
    location: 'Gulshan North, Dhaka',
    year: '2024',
    scale: '14,800 sq. ft.',
    stories: '6 Stories',
    structuralSystem: 'Cast-in-Situ Exposed Concrete & Steel Cantilever',
    summary:
      'A multi-generational urban residence organized around a central vertical wind-shaft courtyard, exposed brick screens, and shaded cantilevered verandas.',
    designThesis:
      'Inspired by the Bengal verandah tradition and contemporary structural clarity, every living level opens onto cross-ventilated landscaped terraces shielded from surrounding mid-rise plots.',
    performanceMetrics: [
      { label: 'Plot Area', value: '10 Katha' },
      { label: 'Cross-Ventilation', value: '100% Living Zones' },
      { label: 'Daylight Autonomy', value: '82% Annual Hours' },
      { label: 'Cantilever Span', value: '3.6m Overhang' },
    ],
    blueprintVariant: 'courtyard',
  },
  {
    id: 'academic-research-center',
    code: 'EC-INS-02',
    title: 'Center for Applied Design & Research',
    category: 'Institutional',
    location: 'Gazipur Academic Corridor',
    year: '2024',
    scale: '92,000 sq. ft.',
    stories: '8 Stories',
    structuralSystem: 'Long-Span Waffle Slab & Shear Wall Frame',
    summary:
      'An academic and engineering complex pairing column-free studio floors with north-facing sawtooth clerestory glazing for glare-free drafting and laboratory work.',
    designThesis:
      'Drawing directly from Principal Architect Faruk Ahmed’s academic tenure at BUET, circulation spines double as informal critique galleries linking structural testing labs with design studios.',
    performanceMetrics: [
      { label: 'Studio Span', value: '14.5m Column-Free' },
      { label: 'Capacity', value: '1,200 Researchers' },
      { label: 'Acoustic Rating', value: 'STC 54 Partitions' },
      { label: 'Rainwater Capture', value: '45,000L Cistern' },
    ],
    blueprintVariant: 'campus',
  },
  {
    id: 'banani-mixed-use',
    code: 'EC-COM-07',
    title: 'Kemal Ataturk Mixed-Use Atrium',
    category: 'Commercial',
    location: 'Banani, Dhaka',
    year: '2023',
    scale: '118,500 sq. ft.',
    stories: '15 Stories + 2 Basements',
    structuralSystem: 'Composite Steel-Concrete Moment Frame',
    summary:
      'Retail podium and boutique office stack featuring modular terracotta sun-breakers, stepped sky-gardens, and high-speed core segregation.',
    designThesis:
      'Separating public retail circulation at levels 1–3 from quiet executive office plates above creates calm acoustic transitions within one of Dhaka’s busiest commercial avenues.',
    performanceMetrics: [
      { label: 'Net-to-Gross Ratio', value: '79% Efficiency' },
      { label: 'Floor-to-Floor', value: '3.95m Clear Slab' },
      { label: 'Elevator Core', value: '4 High-Speed Cars' },
      { label: 'Facade Shading', value: '62% Glazing Shielded' },
    ],
    blueprintVariant: 'mixed',
  },
  {
    id: 'savar-precision-facility',
    code: 'EC-IND-03',
    title: 'Modular Assembly & Logistics Hub',
    category: 'Industrial',
    location: 'Savar Industrial Belt, Dhaka',
    year: '2025',
    scale: '78,000 sq. ft.',
    stories: '3 Stories + Mezzanine',
    structuralSystem: 'Pre-Engineered Steel Portal Frame',
    summary:
      'A high-clearance industrial manufacturing and quality-testing complex integrating passive roof-ridge thermal exhausts and solar-ready truss geometry.',
    designThesis:
      'Industrial architecture warrants the same human dignity and thermal precision as civic buildings. Natural stack ventilation and shaded loading bays cut floor-level heat stress year-round.',
    performanceMetrics: [
      { label: 'Clear Eave Height', value: '11.2m Unobstructed' },
      { label: 'Floor Slab Load', value: '5.0 Ton / sq. m.' },
      { label: 'Natural Ventilation', value: '12 Air Changes/Hr' },
      { label: 'Solar Readiness', value: '420 kWp Roof Grid' },
    ],
    blueprintVariant: 'industrial',
  },
  {
    id: 'baridhara-atrium-villa',
    code: 'EC-RES-09',
    title: 'Monsoon Pavilion & Gallery House',
    category: 'Residential',
    location: 'Baridhara Diplomatic Zone, Dhaka',
    year: '2023',
    scale: '9,600 sq. ft.',
    stories: '4 Stories',
    structuralSystem: 'Reinforced Concrete & Brushed Steel Screens',
    summary:
      'An intimate private residence and architectural art collection gallery wrapped in rhythmic operable metal louvers and shallow cooling water courts.',
    designThesis:
      'Built-in Edifice Home Appliances climate and kitchen assemblies are integrated seamlessly behind flush architectural walnut millwork, uniting interior craftsmanship with mechanical utility.',
    performanceMetrics: [
      { label: 'Built Area', value: '9,600 sq. ft.' },
      { label: 'Glare Control', value: 'Operable Louvers' },
      { label: 'Water Feature', value: 'Evaporative Cooling' },
      { label: 'Appliance Suite', value: 'Edifice Integrated' },
    ],
    blueprintVariant: 'pavilion',
  },
];

export const APPLIANCE_LINES: ApplianceLine[] = [
  {
    id: 'airflow-hoods',
    code: 'EHA-01',
    name: 'Architectural Perimeter Extraction Hoods',
    category: 'Kitchen Ventilation',
    summary:
      'Low-decibel, baffle-filtered range hoods proportioned to sit flush within modern architectural cabinetry without protruding visual bulk.',
    engineeringFocus:
      'Engineered for high-heat South Asian culinary workflows with heavy oil-mist separation and static-pressure ducting for multi-story residential towers.',
    specs: [
      { label: 'Airflow Capacity', value: '1,450 m³/hr' },
      { label: 'Acoustic Rating', value: '48 dBA Low Mode' },
      { label: 'Chassis Material', value: '304 Brushed Steel' },
      { label: 'Installation', value: 'Flush / Island Mount' },
    ],
    architecturalIntegration:
      'Specified directly into Edifice Consultants residential kitchen drawings with zero exposed ducting.',
  },
  {
    id: 'climate-control',
    code: 'EHA-02',
    name: 'Precision Thermal & Dehumidification Units',
    category: 'Climate Hardware',
    summary:
      'High-efficiency climate conditioning and monsoon humidity control systems calibrated for Dhaka’s 85%+ relative humidity seasons.',
    engineeringFocus:
      'Protects fine architectural woodwork, artwork, and interior finishes while maintaining crisp indoor air quality with washable multi-stage filtration.',
    specs: [
      { label: 'Moisture Extraction', value: '50 L / 24 Hours' },
      { label: 'Compressor Type', value: 'Twin-Rotary Inverter' },
      { label: 'Power Efficiency', value: 'COP 4.15 Rated' },
      { label: 'Enclosure', value: 'Powder-Coated Matte' },
    ],
    architecturalIntegration:
      'Concealed slot-diffuser grille compatibility for minimalist plaster and concrete ceilings.',
  },
  {
    id: 'culinary-hobs',
    code: 'EHA-03',
    name: 'Modular Glass & Cast-Iron Culinary Hobs',
    category: 'Built-In Cooking',
    summary:
      'Heavy-gauge tempered ceramic glass and precision brass-burner modular hobs engineered for thermal durability and effortless surface cleaning.',
    engineeringFocus:
      'Flame-failure thermocouple safety valves paired with ergonomic knurled metallic control dials designed by Architect Faruk Ahmed.',
    specs: [
      { label: 'Burner Output', value: '4.5 kW Triple-Ring' },
      { label: 'Surface Plate', value: '8mm Schott Ceramic' },
      { label: 'Pan Supports', value: 'Matte Cast Iron' },
      { label: 'Cutout Standard', value: '730 × 410 mm Flush' },
    ],
    architecturalIntegration:
      'Bevel-free flush countertop mounting aligns cleanly with granite, quartz, and terrazzo slabs.',
  },
  {
    id: 'water-filtration',
    code: 'EHA-04',
    name: 'Under-Counter Pure Hydration & Thermal Systems',
    category: 'Utility & Water',
    summary:
      'Compact under-sink multi-stage mineral filtration and instant-temperature dispensing units eliminating countertop appliance clutter.',
    engineeringFocus:
      'Designed around urban municipal water profiles with high-recovery RO + UV sterilization and solid stainless architectural faucets.',
    specs: [
      { label: 'Purification', value: '6-Stage RO + UV-C' },
      { label: 'Flow Rate', value: '2.2 L / Minute' },
      { label: 'Footprint', value: '140 mm Slim Chassis' },
      { label: 'Faucet Finish', value: 'Anodized Charcoal' },
    ],
    architecturalIntegration:
      'Fits inside standard 600mm sink base modules while keeping storage drawers unobstructed.',
  },
];
