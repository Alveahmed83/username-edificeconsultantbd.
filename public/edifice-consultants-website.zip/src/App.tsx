import { useState } from 'react';
import { ArrowRight, Check } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { ArchitecturalHeroCanvas } from './components/ArchitecturalHeroCanvas';
import { PortfolioSection } from './components/PortfolioSection';
import { AppliancesSection } from './components/AppliancesSection';
import { LeadershipAndCardSection } from './components/LeadershipAndCardSection';
import { ConsultationSection } from './components/ConsultationSection';
import { Footer } from './components/Footer';
import {
  CAPABILITIES,
  COMPANY_INFO,
  STUDIO_METRICS,
} from './data/companyData';

export default function App() {
  const [prefilledSubject, setPrefilledSubject] = useState<string>('');

  const scrollToContact = (subject?: string) => {
    if (subject) {
      setPrefilledSubject(subject);
    }
    const el = document.getElementById('contact');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div id="top" className="min-h-screen flex flex-col bg-[#FAFAFA] text-[#141416]">
      <Navbar onBookConsultation={() => scrollToContact()} />

      <main className="flex-1">
        {/* 1. HERO SECTION: Proposition + Interactive Architectural Canvas */}
        <section className="relative bg-drafting-grid border-b border-zinc-200">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-10 pt-12 pb-14 lg:pt-16 lg:pb-18">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
              {/* Left Typographic Column */}
              <div className="lg:col-span-6 flex flex-col justify-between py-2">
                <div className="space-y-6">
                  <p className="text-xs font-mono tracking-wide text-[#D94A27] font-medium">
                    Edifice Consultants · Bangla Motor, Dhaka-1000
                  </p>

                  <h1 className="font-display text-[clamp(2.25rem,4vw,3.75rem)] leading-[1.08] font-bold tracking-tight text-zinc-950 text-balance">
                    The Nexus of Art &amp; Technology
                  </h1>

                  <p className="text-base sm:text-lg text-zinc-600 leading-relaxed max-w-xl">
                    An integrated architectural consultancy and industrial
                    design practice led by{' '}
                    <span className="font-semibold text-zinc-900">
                      Architect Faruk Ahmed (MIAB A-140)
                    </span>
                    , Former Faculty at the Department of Architecture, BUET.
                    We deliver climate-responsive towers, institutions,
                    residences, and bespoke home appliances.
                  </p>

                  {/* Single Primary CTA + Clean Text Link */}
                  <div className="pt-2 flex flex-wrap items-center gap-5">
                    <button
                      type="button"
                      onClick={() => scrollToContact()}
                      className="inline-flex items-center gap-2.5 px-6 py-3.5 text-sm font-semibold text-white bg-[#D94A27] hover:bg-[#B83819] rounded-md transition-colors duration-150 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D94A27] focus-visible:ring-offset-2"
                    >
                      Schedule Consultation
                      <ArrowRight size={16} />
                    </button>

                    <a
                      href="#portfolio"
                      onClick={(e) => {
                        e.preventDefault();
                        document
                          .getElementById('portfolio')
                          ?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="text-sm font-semibold text-zinc-800 hover:text-[#D94A27] border-b border-zinc-300 hover:border-[#D94A27] pb-0.5 transition-colors whitespace-nowrap shrink-0"
                    >
                      View Architectural Works
                    </a>
                  </div>
                </div>

                {/* Quiet Regional & Studio Attribution */}
                <div className="mt-10 pt-6 border-t border-zinc-200/90 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-zinc-500">
                  <span>{COMPANY_INFO.office.floor}, {COMPANY_INFO.office.building}</span>
                  <span aria-hidden="true">·</span>
                  <a
                    href={`tel:${COMPANY_INFO.principal.phoneRaw}`}
                    className="font-mono text-zinc-700 hover:text-[#D94A27] transition-colors"
                  >
                    {COMPANY_INFO.principal.phoneDisplay}
                  </a>
                  <span aria-hidden="true">·</span>
                  <a
                    href={`mailto:${COMPANY_INFO.office.email}`}
                    className="font-mono text-zinc-700 hover:text-[#D94A27] transition-colors"
                  >
                    {COMPANY_INFO.office.email}
                  </a>
                </div>
              </div>

              {/* Right Dominant Architectural Canvas */}
              <div className="lg:col-span-6">
                <ArchitecturalHeroCanvas />
              </div>
            </div>

            {/* Full-Width 4-Column Credential Strip Below Hero Split */}
            <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 pt-10 border-t border-zinc-200">
              {STUDIO_METRICS.map((item) => (
                <div
                  key={item.label}
                  className="bg-white border border-zinc-200 rounded-xl p-5"
                >
                  <p className="font-mono text-xl sm:text-2xl font-semibold text-zinc-950 tracking-tight">
                    {item.value}
                  </p>
                  <p className="mt-1.5 text-sm font-semibold text-zinc-800">
                    {item.label}
                  </p>
                  <p className="mt-0.5 text-xs text-zinc-500">{item.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 2. CAPABILITIES & PRACTICE BENTO SECTION */}
        <section id="practice" className="py-20 lg:py-28 bg-white">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-10">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end mb-14">
              <div className="lg:col-span-7">
                <p className="text-xs font-mono tracking-wide text-[#D94A27] font-medium mb-3">
                  Multidisciplinary Practice
                </p>
                <h2 className="font-display text-3xl lg:text-4xl font-bold tracking-tight text-zinc-950 text-balance">
                  Engineering precision paired with architectural restraint
                </h2>
              </div>
              <div className="lg:col-span-5">
                <p className="text-base text-zinc-600 leading-relaxed">
                  From statutory RAJUK feasibility and seismic structural frames
                  to custom kitchen and climate hardware, every commission is
                  governed by single-point principal accountability.
                </p>
              </div>
            </div>

            {/* Asymmetric Bento Grid (col-span-2 alongside col-span-1) */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {CAPABILITIES.map((cap) => (
                <div
                  key={cap.index}
                  className={`bg-[#FAFAFA] border border-zinc-200 rounded-xl p-7 flex flex-col justify-between ${
                    cap.spanWide ? 'lg:col-span-2' : 'lg:col-span-1'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-4 mb-4">
                      <span className="font-mono text-sm font-semibold text-[#D94A27]">
                        {cap.index}.
                      </span>
                      <span className="text-xs font-mono text-zinc-500">
                        {cap.highlightMetric}
                      </span>
                    </div>

                    <h3 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-zinc-950">
                      {cap.title}
                    </h3>

                    <p className="mt-3 text-sm sm:text-base text-zinc-600 leading-relaxed max-w-2xl">
                      {cap.scope}
                    </p>
                  </div>

                  <ul className="mt-6 pt-5 border-t border-zinc-200 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {cap.deliverables.map((del) => (
                      <li
                        key={del}
                        className="flex items-start gap-2 text-xs sm:text-sm text-zinc-700"
                      >
                        <Check
                          size={14}
                          className="text-[#D94A27] shrink-0 mt-0.5"
                        />
                        <span>{del}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 3. PORTFOLIO SECTION */}
        <PortfolioSection
          onInquireProject={(projectTitle) => scrollToContact(projectTitle)}
        />

        {/* 4. EDIFICE HOME APPLIANCES DIVISION */}
        <AppliancesSection
          onSelectApplianceInquiry={(applianceName) =>
            scrollToContact(`Edifice Home Appliances — ${applianceName}`)
          }
        />

        {/* 5. PRINCIPAL ARCHITECT & INTERACTIVE VISITING CARD */}
        <LeadershipAndCardSection />

        {/* 6. CONSULTATION BRIEF & BANGALA MOTOR STUDIO */}
        <ConsultationSection prefilledSubject={prefilledSubject} />
      </main>

      <Footer />
    </div>
  );
}
