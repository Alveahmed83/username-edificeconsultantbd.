# Edifice Consultants — Official Website

The Nexus of Art & Technology
Principal Architect: Faruk Ahmed, MIAB A-140
Studio: Floor-19, Planners Tower, Bangla Motor, Dhaka-1000, Bangladesh

## Option 1: Static Hosting (cPanel, Netlify, Vercel, GitHub Pages)
Upload the contents of the `static-build/` folder directly to your web server root (`public_html`).

## Option 2: Local Development / Custom Build
Requires Node.js 18+:
1. `npm install`
2. `npm run dev` (starts local server on port 3000)
3. `npm run build` (outputs production bundle to `dist/`)
